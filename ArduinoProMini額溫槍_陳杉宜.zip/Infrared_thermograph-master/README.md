# Infrared_thermograph
2020/4/6
* 新增程式final_0402.ino (與final_0325不同在於校正方式)
相關說明請參考下列網址：
* https://www.makerlab.tw/post/diyirsensorgun
* http://www.circuspi.com/index.php/2020/02/14/diyirsensorgun/

2020/3/31
* 程式名為final_0325.ino
* 所需要的程式庫在libraries裡
